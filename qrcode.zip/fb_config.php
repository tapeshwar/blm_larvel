<?php

//require_once 'fblogin/src/Facebook/autoload.php';
include_once('fblogin/src/Facebook/autoload.php');
$fb = new Facebook\Facebook(array(
	'app_id' => '147085160944337', // Replace with your app id
	'app_secret' => '1e6388e943a190685367a960ec1f6b9a',  // Replace with your app secret
	'default_graph_version' => 'v3.2',
));

$helper = $fb->getRedirectLoginHelper();
?>