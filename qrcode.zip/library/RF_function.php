<?php
include("RF_config_db.php");

function base_url(){
	$base_url = 'http://localhost/qr/';
	return $base_url;
}

function exeQuery($qry){
$dbObj=conn1();
	return mysqli_query($dbObj,$qry);	
}

function multiQuery($qry){
$dbObj=conn1();
	return mysqli_multi_query($dbObj,$qry);	
}

function inserted_id($qry){
$dbObj=conn1();
	$ret=mysqli_query($dbObj,$qry);
	$inserted_id=mysqli_insert_id($dbObj);
	return ($inserted_id)?$inserted_id:$ret;
}

function fetchAssoc($res){
	return mysqli_fetch_assoc($res);
}

function num_res($res){
	return mysqli_num_rows($res);
}

function num_fields($res){
	return mysqli_num_fields($res);
}

function field_name($res){
	return mysqli_fetch_field($res);
}

function filterVar($val){
	return addslashes($val);
}



//================ To get the list of senior Employees email id =============//
			
function send_notification ($tokan_ids=false,$resMsg=false,$message=false){
	define( 'API_ACCESS_KEY', 'AAAA4QxpobI:APA91bGKJ80b2iZbFgPI73JNjXV4i0BJgSzhlYOomEqHpUE8_J264g3QQQlqFSiqNJygOIxsHzH2Idp5qsooJ9AqtbpC8gxWPYvdp_qV4VgZrYndzZLrhTKA_gF2byo5bTIeTOeX6Q5j');
	$registrationIds = $tokan_ids;
	$msg = array('title' => 'New order','icon'  => 'myicon','sound' => 'mySound','priority'  => 'high');
	$fields = array('registration_ids'    => $registrationIds,'data' => $resMsg );
	$headers = array('Authorization: key=' . API_ACCESS_KEY,'Content-Type: application/json');

	$ch = curl_init();
	curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
	curl_setopt( $ch,CURLOPT_POST, true );
	curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
	curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
	curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
	curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
	$result = curl_exec($ch );
	curl_close( $ch );
	echo $result;
}



function get_location($lat,$long){
    $url="https://maps.googleapis.com/maps/api/geocode/json?latlng=".$lat.",".$long."&sensor=true_or_false&key=AIzaSyAWKwKMx4iP4bvfMpvTTH1HQ13aVgTaSCA";
    $init = curl_init();
    curl_setopt($init, CURLOPT_URL, $url);
    curl_setopt($init, CURLOPT_HEADER,0);
    curl_setopt($init, CURLOPT_USERAGENT, $_SERVER["HTTP_USER_AGENT"]);
    curl_setopt($init, CURLOPT_RETURNTRANSFER, 1);
    $response = curl_exec($init);
    curl_close($init);
    $location = json_decode($response, true);
    return $location['results']['0']['formatted_address'];
}

function create_employee_activity($input){

		$user_id=$input['user_id'];
		$activities_name=$input['activities_name'];
		$activities_type=$input['activities_type'];
		$created_for=$input['created_for'];
		$datetime=$input['activitydatetime'];
		$apk_version=$input['apk_version'];
		$server_id=$input['server_id'];
		$device_id=$input['device_id'];
		$currentTime=$input['currentTime'];
		
		$createAct="";
		//$createAct = exeQuery("INSERT INTO activity (u_id,activity,act_type,created_for,date_time,apk_version,server_id,modified,created)
		//VALUES ('$user_id','$activities_name','$activities_type','$created_for','$datetime','$apk_version','$server_id','$currentTime','$currentTime')");
		
		$createAct="INSERT IGNORE INTO activity SET 
            		u_id='".$user_id."', 
            		activity='".$activities_name."', 
            		act_type='".$activities_type."', 
            		created_for='".$created_for."', 
            		date_time='".$datetime."',
                    apk_version='".$apk_version."',
                    server_id='".$server_id."', 
                    created='".$datetime."',
                    modified='".$datetime."';";
                    exeQuery($createAct);
		            return true;
	            }
	            
?>