<?php
session_start();
include("RF_table.php");
// shows connectivity to database
function conn1()
{
	$link = mysqli_connect(LOCALHOST, USERNAME, PASSWORD,DATABASE)or die(LOCALHOST." - ".USERNAME." - ".PASSWORD." - ".DATABASE);
	return $link;
}
?>