<?php
// define DATABASE and all table used in software
date_default_timezone_set("Asia/Kolkata");
//error_reporting(0);

define("LOCALHOST","localhost");
define("USERNAME","root");
define("PASSWORD","");
define("DATABASE","qrcode");

define("BASE_URL","http://localhost/qr/");
//define("BASE_URL","https://auraine.co.in/qr/");

define("ERROR404","error-404.php");

define("INSERT_MSG","Record have been successfully inserted");
define("UPDATE_MSG","Record have been successfully updated");
define("DELETE_MSG","Record have been successfully deleted");

define("INSERT_ERROR","Record have not been inserted");
define("UPDATE_ERROR","Record have not been updated");
define("DELETE_ERROR","Record have not been deleted");
define("ERROR_MSG","Fail to execute...");




?>