<?php
    //DB details
    $dbHost = 'localhost';
    $dbUsername = 'root';
    $dbPassword = '';
    $dbName = 'qrcode';
     //Create connection and select DB
            $db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);
        if ($db->connect_error) {
            die("Unable to connect database: " . $db->connect_error);
        }
        
   session_start();
    include_once('fb_config.php');
    $permissions = array('email'); // Optional permissions
    $loginUrl = $helper->getLoginUrl('https://auraine.co.in/qr/fb-callback.php', $permissions);
    $createdon=date('Y-m-d H:i:s');
    
    //print_r($_SESSION);
    
    $ip = $_SERVER['REMOTE_ADDR'];
    date_default_timezone_set("Asia/Kolkata");
    $cdate = date("Y-m-d H:i:s");

        if(isset($_GET['uq'])){
            $_SESSION['qrs_number_act'] = $_GET['uq'];
            $_SESSION['qrs_number'] = base64_decode(urldecode($_GET['uq']));
        }else{
            //$varId = $_SESSION['qrs_number_act'];//urlencode(base64_encode($_SESSION['qrs_number_act']));
           // $_SESSION['qrs_number']="";
            //exit();
        }

        if(isset($_POST['visitoraction'])){
            $verified = "yes";
        }else{
           $verified = "no"; 
        }
     
        //check user if sign in
        if(isset($_COOKIE['verified_qr']) AND isset($_SESSION['getlat']) AND $verified == "no"){

             //Get details of visitor
            $uQuery = $db->query("SELECT * FROM `auth` WHERE email = '".$_COOKIE['verified_qr']."' ");
            $userDetail = $uQuery->fetch_assoc();
         
            $name = $userDetail['name'];
			      $email = $userDetail['email'];
			      $phone = $userDetail['phone'];
            
            //Get Geocode
            /*$url = "https://www.googleapis.com/geolocation/v1/geolocate?key=AIzaSyCKujbP3gEUfWWA8Igiw7wGUE2KsuCfaVc";
            $data = ['collection' => 'RapidAPI'];
            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS,  json_encode($data));
            curl_setopt($curl, CURLOPT_HTTPHEADER, [
              'X-RapidAPI-Host: kvstore.p.rapidapi.com',
              'X-RapidAPI-Key: AIzaSyCKujbP3gEUfWWA8Igiw7wGUE2KsuCfaVc',
              'Content-Type: application/json'
            ]);
            $response = curl_exec($curl);
            curl_close($curl);
            $getLoc = json_decode($response, true);*/
            //echo $lat = $getLoc['location']['lat'];
            //echo $lng = $getLoc['location']['lng'];
            
            //$lat = '28.5057948';
            //$lng = '77.06794769999999';
            
            //Get Address
            $url = "https://maps.googleapis.com/maps/api/geocode/json?latlng=".$_SESSION['getlat'].",".$_SESSION['getlong']."&key=AIzaSyCKujbP3gEUfWWA8Igiw7wGUE2KsuCfaVc";
            $content = file_get_contents($url);
            $getAddress = json_decode($content, true);
            //echo "<pre>";
            //print_r($getAddress['results'][5]['address_components']);
            	$city = $getAddress['results'][5]['address_components'][5]['long_name'];
            	$state = $getAddress['results'][5]['address_components'][6]['long_name'];
            	$country = $getAddress['results'][5]['address_components'][7]['long_name'];
            	$countryCode = $getAddress['results'][5]['address_components'][7]['short_name'];
            	$postalCode = $getAddress['results'][5]['address_components'][8]['long_name'];
            	
            	$db->query("INSERT INTO visitor_info SET 
                        unique_code = '".$_SESSION['qrs_number']."',
                        ip = '".$ip."',
                        browserName = '',
                        v_name='".$name."',
        			          v_email='".$email."',
        			          v_phone='".$phone."',
                        city = '".$city."',
                        state = '".$state."',
                        region = '', 
                        regionName = '', 
                        countryCode = '".$countryCode."',                       
                        countryName= '".$country."',
                        latitude= '".$_SESSION['getlat']."',
                        longitude= '".$_SESSION['getlong']."',
                        timezone= '',
                        updated_on= '".$cdate."',
                        created_date_time= '".$cdate."'
                        ");
            
        }
        if(!isset($_COOKIE['verified_qr'])){
                require 'google-api/vendor/autoload.php';
                // Creating new google client instance
                $client = new Google_Client();
                
                // Enter your Client ID
                $client->setClientId('663099829786-97brarkuekirkjue9l7o0c9maa122c97.apps.googleusercontent.com');
                // Enter your Client Secrect
                $client->setClientSecret('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');
                // Enter the Redirect URL
                $client->setRedirectUri('https://auraine.co.in/qr/verify.php');
                
                // Adding those scopes which we want to get (email & profile Information)
                $client->addScope("email");
                $client->addScope("profile");
                
                
                if(isset($_GET['code'])){
                    $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);
                    $client->setAccessToken($token['access_token']);
                
                    // getting profile information
                    $google_oauth = new Google_Service_Oauth2($client);
                    $google_account_info = $google_oauth->userinfo->get();
                    
                      
                      $prevResult = $db->query("SELECT * FROM auth WHERE email='".$google_account_info->email."'");
                      //$res = $prevResult->fetch_assoc();
                      $rowcount=mysqli_num_rows($prevResult);
                     // print_r($rowcount);
                    if($rowcount <=0){
                        $db->query("INSERT INTO auth SET
                			name='".$google_account_info->name."',
                			email='".$google_account_info->email."',
                			phone='0',
                			picture='".$google_account_info->picture."',
                			created_on='".$createdon."' ");
                    }
                        $cookie_name = "verified_qr";
                        setcookie($cookie_name, $google_account_info->email, time() + (86400 * 30*365), "/"); 
                    
                    
                    //header ("Location : verify.php");
                    $yourURL="https://auraine.co.in/qr/verify.php?uq=".$_SESSION['qrs_number_act'];
                    echo ("<script>location.href='$yourURL'</script>");
                
                }
                
        }
        
            //Receive visitor information
    		if(isset($_POST['submit']) AND $_POST['submit'] == "Claim your reward"){
    			$name = addslashes($_POST['vname']);
    			$email = addslashes($_POST['vemail']);
    			$phone = addslashes($_POST['vphone']);
    			$six_digit_random_number = random_int(100000, 999999);	
    			
    			$prevResult = $db->query("SELECT * FROM auth WHERE email='".$email."'");
                $rowcount=mysqli_num_rows($prevResult);
                
                    if($rowcount <=0){
                        $db->query("INSERT INTO auth SET
                			name='".$name."',
                			email='".$email."',
                			phone='".$phone."',
                			verification_code='".$six_digit_random_number."',
                			created_on='".$createdon."' ");
                    }else{
                        $db->query("update auth SET
                			verification_code='".$six_digit_random_number."'
                			where email='".$email."' ");
                    }
                    
                    $to = $email;
                    $subject = $six_digit_random_number." is your product confirmation code";
                    $message = "
                    <html>
                    <head>
                    <title>Verification</title>
                    </head>
                    <body>
                    <p>Dear ".$name.",</p>
                    <table>
                    <tr>
                    <th>You recently registered for product verification. To complete your product verification, please confirm your account.</th>
                    </tr>
                    </table>
                    </body>
                    </html>
                    ";
                    
                    // Always set content-type when sending HTML email
                    $headers = "MIME-Version: 1.0" . "\r\n";
                    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                    
                    // More headers
                    $headers .= 'From: <support@glamourbook.com>' . "\r\n";
                    //$headers .= 'Cc: myboss@example.com' . "\r\n";
                    
                    $resp = mail($to,$subject,$message,$headers);

    			if($resp ==1){$msg = "Your detail submitted successfully.";}else{$msg = "Re-try again.";}
    		}
    		
    		//Enter your verification code
    		if(isset($_POST['submit']) AND $_POST['submit'] == "Verify & Claim Your Reward"){
    			$vercode = addslashes($_POST['vercode']);
    			$vemail = addslashes($_POST['visitoremail']);

    			$prevResult = $db->query("SELECT * FROM auth WHERE email='".$vemail."' AND verification_code='".$vercode."' ");
                $rowcount=mysqli_num_rows($prevResult);
               
                    if($rowcount >=1){
                        $exe = $db->query("update auth SET
                			verification_code='1'
                			where email='".$vemail."' ");
                        if($exe){
                    		$cookie_name = "verified_qr";
                            setcookie($cookie_name, $vemail, time() + (86400 * 30*365), "/"); 	
                    		$yourURL="https://auraine.co.in/qr/verify.php?uq=".$_SESSION['qrs_number_act'];
                             echo ("<script>location.href='$yourURL'</script>");
                        }
                    }else{
                        $msg = "Incorrect verification code.";
                    }
    		}
    		
        //Confirm Reseller
             if(isset($_POST['confirm'])){
                 session_destroy();
                 $creseller = $_POST['creseller'];
                 $visitorid = $_POST['visitorid'];
                 $db->query("update visitor_info set
            			  confirm_reseller='".$creseller."'
            			  where visitor_id='".$visitorid."' ");
                }


        //Get details of visitor
            $prevQuery = "SELECT vi.*,b.brand_name FROM visitor_info as vi 
            LEFT JOIN qr_codes as qc ON ( qc.unique_code=vi.unique_code )
            LEFT JOIN brands as b ON (b.brand_id=qc.brand_id )
            WHERE vi.ip = '".$ip."' ORDER BY vi.created_date_time DESC";
            $prevResult = $db->query($prevQuery);
            $resp = $prevResult->fetch_assoc();
   ?>
   
  <!DOCTYPE html>
  <html lang="en">
  <head>
  <title>Success</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php if(!isset($_SESSION['getlat'])){?>
    <!-- <meta http-equiv="refresh" content="3;url=https://auraine.co.in/qr/verify.php" /> -->
  <?php } ?>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="preconnect" href="https://fonts.gstatic.com">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
  	@media (min-width: 576px){
			.container, .container-sm { max-width: 540px !important; }
		}
		p{ margin-bottom: 2px; }
		p, div, a, h2, h1, h3, h4, span {font-family: 'Syne', sans-serif;	font-variant-numeric: lining-nums !important; }
		.boxs { background: #fffce426; margin: 20px 30px; padding: 30px 15px; box-shadow: 0px 0px 3px 0px #d7d7d7;}
		.logos a{ font-size: 50px; text-decoration: none;color: #000 !important;}
  	.buttons-se a{ text-decoration: none !important; color: #fff !important; border: 1px solid #000; background: #000; padding: 10px 20px;letter-spacing: 1px; font-size: 12px;}
  	.seri-dis{ font-size: 12px;  }
	/*.submit-forms{ position: relative;}
	.submit-forms .logo-box{ position: absolute; top: -15px; right: 0px; width:70px;}*/
	.submit-forms .logo-box{ width:160px; margin: 0 auto; margin-bottom: 5px;}
	.submit-forms .logo-box img{ width:100%;}
	
.social {
    transition: background 200ms ease-in-out 0s;
    -webkit-transition: background 200ms ease-in-out 0s;
    -moz-transition: background 200ms ease-in-out 0s;
    -o-transition: background 200ms ease-in-out 0s;
    -ms-transition: background 200ms ease-in-out 0s;
    margin-top: 12px;
    -webkit-border-top-left-radius: 1px;
    -moz-border-radius-topleft: 1px;
    border-top-left-radius: 1px;
    -webkit-border-top-right-radius: 1px;
    -moz-border-radius-topright: 1px;
    border-top-right-radius: 1px;
    -webkit-border-bottom-right-radius: 1px;
    -moz-border-radius-bottomright: 1px;
    border-bottom-right-radius: 1px;
    -webkit-border-bottom-left-radius: 1px;
    -moz-border-radius-bottomleft: 1px;
    border-bottom-left-radius: 1px;
    text-indent: 0;
    display: block;
    color: #ffffff !important;
    height: 50px;
    text-decoration: none;
    line-height: 48px;
    width: 100%;
    text-decoration: none;
    text-align: center;
}
.social span {
    margin-left: 10px;
}
.fblogin {   
  background-color:#3b5898;  
}
.fblogin:hover {
  background-color:#5177c2;
}
.fblogin:active {
  position:relative;
  top:1px;
}
.gplogin {  
  background-color:#dd4c39; 
}
.gplogin:hover {
  background-color:#f06e60;
}
.gplogin:active {
  position:relative;
  top:1px;
}
.img-section {
    width: 76px;
    height: 48px;
    border-left: 1px solid #000;
}
.liveable_logo {
    width: 90px !important;
}
.img-section:first-child{ border:none;}
.logo-comm {
    width: 55px;
}
.img-section {
    padding-left: 9px;
    padding-right: 5px;
}
  	@media only screen and (max-width: 767px) {
  		.boxs { margin: 5px 0px; padding: 0px 0px; }
  	}
  </style>
    </head>
    <body>


  <section class="main-sections">
  	<div class="container">
		  <div class="row">
		    <div class="col-sm-12">
		    	<div class="boxs text-center">
				<div class="submit-forms">
					
					<?php if(isset($_COOKIE['verified_qr'])){?>
					<h3 class="first-title text-uppercase font-weight-bold mb-4">Dear, <?php echo $resp['v_name'];?></h3>
					<div class="logo-box">
						<img src="img/200.png" class="">
					  </div>
					<p class="seri-dis mb-4 text-uppercase font-weight-bold">This is to certify that this product is authentic and genuine <?php echo $resp['brand_name'];?> product and is sold by our authorized reseller.</p>
					<p class="seri-dis text-uppercase font-weight-bold">All <?php echo $resp['brand_name'];?> products are if used with 100% natural keratin blend GK Juvacine to keep your healthy soft and shiny.</p>
					  
					<p class="seri-dis text-center mt-2 mb-4 text-uppercase font-weight-bold">Please confirm if this product was purchased from a reseller in <?php echo $resp['city'];?>.</p>
					
						<div class="logo-box">
						<?php if($resp['brand_name'] == "GK Hair"){ ?>
						<img src="img/150.png" class="" style="width:50px" >
						<?php }elseif($resp['brand_name'] == "Tibolli"){ ?>
						<img src="img/tibolli-logo.png" class="" style="width:80px" >
						<?php }elseif($resp['brand_name'] == "live.able"){ ?>
						<img src="img/liveable-logo.png" class="" style="width:150px" >
						<?php } elseif($resp['brand_name'] == "pH Laboratories"){ ?>
						<img src="img/ph.png" class="" style="width:80px" >
						<?php } ?>
					  </div>
					
					<p class="text-center">
						<form method="post" action="" class="mt-2">
						    <input type="hidden" name="visitorid" value="<?php echo $resp['visitor_id'];?>">
						    <input type="hidden" name="visitoraction" value="verified">
							<div class="form-check-inline">
							  <label class="form-check-label seri-dis text-uppercase font-weight-bold" for="radio1">
								<input type="radio" class="form-check-input" id="radio1" name="creseller" value="1" required>yes
							  </label>
							</div>
							<div class="form-check-inline">
							  <label class="form-check-label seri-dis text-uppercase font-weight-bold" for="radio2">
								<input type="radio" class="form-check-input" id="radio2" name="creseller" value="0" required>no
							  </label>
							</div>
							<br>				
							
							<div class="form-group mt-4">
							<input type="submit" name="confirm" value="Confirm" class="btn btn-primary btn-dark seri-dis text-uppercase font-weight-bold">
						  </div>
						  </form>
					</p>
				</div> 
						
					<!--<p class="logos color-dark">
						<a href="#" title="" alt="" class=" text-uppercase font-weight-bold ">
							<img src="https://abgo.in/bookmyservice/images/checkm.gif" alt="" width="15%">
						</a>
					</p>-->
					<?php 
					    } 
					if(!isset($_COOKIE['verified_qr']) || $_SESSION['e_verification'] =='1'){ 
					?>

					  <?php if(isset($_POST['submit']) AND $_POST['submit'] == "Claim your reward"){ ?>
					  <div class="logo-box">
						<img src="img/200.png" class="">
					  </div>
        					  <h5 class="first-title text-uppercase font-weight-bold">
        					      Verification code sent to your registered email address. Please check your email.
        					      </h5>
        					<p class="seri-dis mb-2 text-uppercase"></br></p>
        					<p class="text-center">Enter 6-digit verification code here.</p>
					        <form method="post">
						        <div class="row">
					                    <input type="hidden" name="visitoremail" value="<?php echo $email;?>">
					                <div class="col-sm-12">
                						  <div class="form-group">
                							<input type="text" name="vercode" placeholder="Enter 6 digit number" class="form-control" required>
                						  </div>
                					</div>
				                    <div class="col-sm-12">
        						          <div class="form-group">
        							        <input type="submit" name="submit" value="Verify & Claim Your Reward" class="btn btn-primary btn-dark">
        						          </div>
        						    </div>
        						</div>
					        </form>
					  
					 <?php } else{?>
					 <div class="logo-box">
						<img src="img/200.png" class="">
					  </div>
					 <h3 class="first-title text-uppercase font-weight-bold">Sign In to verify your product.</h3>
					<p class="seri-dis mb-2 text-uppercase"></p>				
					<p class="text-center"><?php //echo $msg; ?></p>
					    <form method="post">
						   <div class="row">
							<div class="col-sm-6">
								<a href="<?= htmlspecialchars( $loginUrl ); ?>" class="fblogin social">
									<i class="fa fa-facebook"></i><span>Sign in with Facebook</span>
								</a>
							</div>
							<div class="col-sm-6">
								<a href="<?php echo $client->createAuthUrl(); ?>" class="gplogin social">
									<i class="fa fa-google"></i><span>Sign in with Google</span>
								</a>  
							</div>
						   </div>
						   <br>
						   <div class="">
							<input type="hidden" name="visitorid" value="<?php echo $resp['visitor_id'];?>">
						  <div class="form-group">
							<input type="text" name="vname" placeholder="Your Name" class="form-control" required>
						  </div>
						  <div class="form-group">
							<input type="email" name="vemail" placeholder="Your Email" class="form-control" required>
						  </div>
						  <div class="form-group">
							<input type="tel" name="vphone" placeholder="Your Phone" class="form-control" required>
						  </div>
						  <div class="form-group">
							<input type="submit" name="submit" value="Claim your reward" class="btn btn-primary btn-dark">
						  </div>
						   </div>
					 </form>
					 <?php } ?>
					 <?php }else{ ?>
					 <!--<h3 class="first-title text-uppercase font-weight-bold mb-4">Error!!!</h3>-->
				<?php } ?>
		      </div>
			  <div class="box-logosection d-flex justify-content-around align-items-center  mt-3 mb-2">
				<div class="img-section logo-comm gk_logo d-flex justify-content-center align-items-center">
					<a href="https://www.gkhair.co.in/" title="Gkhair" class="text-decoration-none"><img src="img/150.png" class="img-fluid"></a>
				</div>
				<div class="img-section tibolli_logo  d-flex justify-content-center align-items-center">
					<a href="http://tibolli.co.in/" title="tibolli" class="text-decoration-none"><img src="img/tibolli-logo.png" class="img-fluid"></a>
				</div>
				<div class="img-section liveable_logo  d-flex justify-content-center align-items-center">
					<a href="https://www.iliveable.com/" title="liveable" class="text-decoration-none"><img src="img/liveable-logo.png" class="img-fluid"></a>
				</div>
					<div class="img-section ph_logo logo-comm  d-flex justify-content-center align-items-center">
					<a href="https://www.phlaboratories.in/" title="pH" class="text-decoration-none"><img src="img/ph.png" class="img-fluid"></a>
				</div>
				<div class="img-section keune_logo d-flex justify-content-center align-items-center">
					<a href="https://www.keune.com/" title="keune" class="text-decoration-none"><img src="img/keune.png" class="img-fluid"></a>
				</div>
				
			  </div>
		    </div>
		  </div>
		</div>
  </section>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script>
    $(document).ready(function(){
    	if ("geolocation" in navigator){ //check geolocation available 
    	//try to get user current location using getCurrentPosition() method
    	navigator.geolocation.getCurrentPosition(function(position){ 
    			console.log("Found your location \nLat : "+position.coords.latitude+" \nLang :"+ position.coords.longitude);
    			var get_user_latitude=position.coords.latitude; 
    		    var get_user_longitude=position.coords.longitude;
    			
    		    $.ajax({
    				method: "POST",
    				url:"https://auraine.co.in/qr/get_locations.php",
    				data:{ "latitude":get_user_latitude,"longitude":get_user_longitude},
    				success : function(response) {
    					//location.reload();
    					//setInterval(window.location.href="info.php", 2000);
    					//setInterval('location.reload()', 1000);
    					}
    			})
    		});
    	  }
    	});
  </script>
</body>
</html>
