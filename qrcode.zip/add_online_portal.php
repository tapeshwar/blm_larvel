<?php
include "library/RF_function.php";
if(isset($_POST['store_online_portal'])){
    $name = addslashes($_REQUEST['name']);
    $url = addslashes($_REQUEST['portal_url']);
    $desc = addslashes($_REQUEST['desc']);
    $status = addslashes($_REQUEST['status']);
    if(!empty($_FILES['fil_image'])){
        if(@$_FILES['fil_image']['tmp_name']!=""){
            $set = '';
        $image_name=time().$_FILES['fil_image']['name'];
        if($_FILES['fil_image']['type']=="image/png" or $_FILES['fil_image']['type']=="image/jpeg" or $_FILES['fil_image']['type']=="image/gif"){
            $file_move=move_uploaded_file($_FILES['fil_image']['tmp_name'],"uploads/".$image_name);
            if($file_move){
            $set.=" , logo='".$image_name."'";
            }
        }
        }
    }
     
    $sqlInsert = exeQuery("INSERT INTO online_portal SET
		 	name = '".$name."',
			url = '" . $url . "',
            status = '" .$status. "',
            description = '" . $desc . "' $set
            
            ");
    header('Location:online_portals.php');       
    exit();

}

?>

<div class="modal-header modal-primary">
    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>Add Online Portal 
</div>
<div class="modal-body">
<form id="add_module_form" action="add_online_portal.php" method="post" class="form-horizontal" enctype="multipart/form-data">
    <div class="row">
            <div class="col-sm-8">
                <label class="control-label">Name:</label>
                <input type="text" name="name" class="form-control" placeholder="Name" required data-msg-required="Name is required"> 
            </div>
        
            <div class="col-sm-8">
                <label class="control-label">Portal URL:</label>
                <input type="text" name="portal_url" class="form-control" placeholder="Portal URL">
            </div>
            <div class="col-sm-8">
                <label class="control-label">Logo:</label>
                <input type="file" class="form-control" name="fil_image">
            </div>

            <div class="col-sm-8">
                <label class="control-label">Description:</label>
                <textarea name="desc" class="form-control"></textarea>
            </div>

            <div class="col-sm-6">
                <label class="control-label">Status:</label>
                <select name="status" class="form-control">
                    <option value="1">Enabled</option>
                    <option value="0">Disabled</option>
                </select>
            </div>


        <div class="col-md-8" style="margin-top: 20px;">       
            <button type="submit" name="store_online_portal" class="btn btn-primary btn-md btn-flat store_module_btn">Submit</button>
        </div>

    </div>
    </form>
</div>
