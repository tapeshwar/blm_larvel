<?php

    //DB details
    $dbHost = 'localhost';
    $dbUsername = 'aurainec_hrms';
    $dbPassword = 'aurainec_hrms@123';
    $dbName = 'aurainec_qrsc_code';
     //Create connection and select DB
            $db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);
        if ($db->connect_error) {
            die("Unable to connect database: " . $db->connect_error);
        }
        
session_start();
$createdon=date('Y-m-d H:i:s');
include_once('fb_config.php');

try {
  $accessToken = $helper->getAccessToken();
} catch(Facebook\Exceptions\FacebookResponseException $e) {
  // When Graph returns an error
  echo 'Graph returned an error: ' . $e->getMessage();
  exit;
} catch(Facebook\Exceptions\FacebookSDKException $e) {
  // When validation fails or other local issues
  echo 'Facebook SDK returned an error: ' . $e->getMessage();
  exit;
}

if (!isset($accessToken)) {
  if ($helper->getError()) {
    header('HTTP/1.0 401 Unauthorized');
    echo "Error: " . $helper->getError() . "\n";
    echo "Error Code: " . $helper->getErrorCode() . "\n";
    echo "Error Reason: " . $helper->getErrorReason() . "\n";
    echo "Error Description: " . $helper->getErrorDescription() . "\n";
  } else {
    header('HTTP/1.0 400 Bad Request');
    echo 'Bad request';
  }
  exit;
}

if(!$accessToken->isLongLived()){
  // Exchanges a short-lived access token for a long-lived one
  try {
    $accessToken = $oAuth2Client->getLongLivedAccessToken($accessToken);
  } catch (Facebook\Exceptions\FacebookSDKException $e) {
    echo "<p>Error getting long-lived access token: " . $e->getMessage() . "</p>\n\n";
    exit;
  }
}

//$fb->setDefaultAccessToken($accessToken);

# These will fall back to the default access token
//$res 	= 	$fb->get('/me',$accessToken->getValue());
$res = $fb->get('/me?fields=name,first_name,last_name,email,link,gender,locale,birthday,cover,picture.type(large)',$accessToken->getValue());
$fbUser	=	$res->getDecodedBody();


$resImg		=	$fb->get('/me/picture?type=large&amp;amp;redirect=false',$accessToken->getValue());
$picture	=	$resImg->getGraphObject();


$_SESSION['fbUserId']		=	$fbUser['id'];
$_SESSION['fbUserName']		=	$fbUser['name'];
$_SESSION['fbAccessToken']	=	$accessToken->getValue();

$prevResult = $db->query("SELECT * FROM auth WHERE email='".$fbUser['email']."'");

  //$res = $prevResult->fetch_assoc();
  $rowcount=mysqli_num_rows($prevResult);
 // print_r($rowcount);
if($rowcount <=0){
    $db->query("INSERT INTO auth SET
		name='".$fbUser['name']."',
		email='".$fbUser['email']."',
		phone='0',
		picture='".$fbUser['picture']['url']."',
		created_on='".$createdon."' ");
}
    $cookie_name = "verified_qr";
    setcookie($cookie_name, $fbUser['email'], time() + (86400 * 30*365), "/");
$varId = '123456789';
$yourURL="https://auraine.co.in/qr/verify.php";
echo ("<script>location.href='$yourURL'</script>");
//header('Location: welcome.php');
//exit;
?>