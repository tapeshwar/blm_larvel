<?php 
 include "library/RF_function.php";

	if(isset($_SESSION["user_id"]) == 0){
	   header("location:login.php");
	}
	//Generate Qr code
	if(isset($_REQUEST['generateQR'])){

		$brand=addslashes($_REQUEST['brand']);
		$state=addslashes($_REQUEST['state']);
		$city=addslashes($_REQUEST['city']);
		$validate=addslashes($_REQUEST['validate']);
		$createdon=date('Y-m-d H:i:s');
		$sqlins ="";
		
			$unique=strtoupper(substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz", 5)), 0, 5));
			$uniqueCode=time().''.$unique.''.RAND(10000,99999);
			$codeenc = urlencode(base64_encode($uniqueCode));
			$uniqURL=BASE_URL.'verify.php?uq='.$codeenc;
			 
			//echo "--";
		    //echo $codeenc1 = base64_decode(urldecode($codeenc));
			$qrcodeURL="https://chart.googleapis.com/chart?cht=qr&chs=350x350&chl=".$uniqURL."&choe=UTF-8";
			//echo $qrcodeURL;die;
			$imageName = time().'.bmp';
			qrCode(350,$imageName,$uniqURL);
			
			$sqlins.="INSERT INTO qr_codes SET
			brand_id='".$brand."',
			state_id='".$state."',
			city_id='".$city."',
			unique_code='".$uniqueCode."',
			unique_url='".$uniqURL."',
			code_url='".$qrcodeURL."',
			qr_code_image='".$imageName."',
			validate_with='".$validate."',
			final_status='1',
			updated_on='".$createdon."';";

		$executed=multiQuery($sqlins);  
		

		if($executed){
			$_SESSION['sess_msg']="The QR Code has been generated successfully!";
			$_SESSION['types']="success";
		}else{
			$_SESSION['sess_msg']="Something went wrong with the system please try after sometimes or contact to IT Department!";
			$_SESSION['types']="danger";
		}
		header("Location:qrcodes.php");
		exit();    
	}
	
	//Generate QR Code Image
	function qrCode($size = 350, $filename = null, $uniqURL) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'http://chart.apis.google.com/chart');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "chs={$size}x{$size}&cht=qr&chl=" . $uniqURL);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        $img = curl_exec($ch);
        curl_close($ch);
    
        if($img) {
            if($filename) {
                if(!preg_match("#\.bmp#i", $filename)) {
                    $filename .= ".bmp";
                }
                $path = "qr_image/".$filename;
                return file_put_contents($path, $img);
            } else {
                header("Content-type: image/bmp");
                //print $img;
                return true;
            }
        }
        return false;
    }

 include "include/header.php";
 include "include/sidebar.php";
 
 
$sqlbrand=exeQuery("select brand_id,brand_name from brands where status='1' ORDER BY brand_name");
$sqlstate=exeQuery("select state_id,state_name from states where status='1' ORDER BY state_name");
//$resbrand=fetchAssoc($sqlstate);

?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Create Code</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Create Code</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-6">
            <!-- jquery validation -->
            <div class="card card-primary">
              <!--<div class="card-header">
                <h3 class="card-title">Create QR code <small></small></h3>
              </div>-->
              <!-- /.card-header -->
              <!-- form start -->
              <form method="post">
                <div class="card-body">
				<div class="form-group">
                    <label for="">Brand</label>
                        <select name="brand" class="form-control">
							<option value="">--Select Brand--</option>
							<?php while($resbrand = fetchAssoc($sqlbrand)){?>
							<option value="<?php echo $resbrand['brand_id'];?>"><?php echo $resbrand['brand_name'];?></option>
							<?php }?>
						</select>

                  </div>
                  <div class="form-group">
                    <label for="">State</label>
                        <select name="state" id="state" class="form-control">
							<option value="">--Select State--</option>
							<?php while($resstate = fetchAssoc($sqlstate)){?>
							<option value="<?php echo $resstate['state_id'];?>"><?php echo $resstate['state_name'];?></option>
							<?php }?>
						</select>
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">City</label>
                          <select name="city" id="city" class="form-control">
								<option value="">--Select City--</option>
						  </select>
                  </div> 
					<div class="form-group">
                    <label for="exampleInputEmail1">Geofencing</label>
                          <select name="validate" class="form-control">
								<option value="">--Select--</option>
								<option value="1">State</option>
								<option value="2">City</option>
						  </select>
                  </div>
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" name="generateQR" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">

          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php include "include/footer.php";?>
<script>
	$(document).ready(function(){
		//State
		$('#state').on('change',function(){
        var state_id = $(this).val();

            if(state_id){
                $.ajax({
                    type:'POST',
                    url:'ajaxData.php',
                    data:{'state_id':state_id},
					success:function(data){
						$("#city").html(data);
					}
                }); 
            }else{
                $('#city').html('<option value="">Select State first</option>'); 
            }
         });
	});
</script>