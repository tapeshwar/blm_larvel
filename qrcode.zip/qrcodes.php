<?php 
 include "library/RF_function.php";

	if(isset($_SESSION["user_id"]) == 0){
	   header("location:login.php");
	}
				$sqlqr=exeQuery("SELECT qc.*, c.city_name, s.state_name,b.brand_name,p.product_name, p.product_sku, p.product_code FROM qr_codes as qc 
					LEFT JOIN brands as b ON (b.brand_id=qc.brand_id ) 
					LEFT JOIN cities as c ON (c.city_id=qc.city_id) 
					LEFT JOIN states as s ON (s.state_id=qc.state_id) 
          LEFT JOIN products as p ON (p.product_id=qc.product_id)
					WHERE 1 ORDER BY qc.updated_on DESC");
					//$resbundle=fetchAssoc($sqlqr);
					//print_r($resbundle);
?>
<?php include "include/header.php";?>
<?php include "include/sidebar.php";


?>

<style>
.content_new-section .table-bordered td, .content_new-section .table-bordered th {
    border: 1px solid #dee2e6;
    font-size: 14px;
}

.content_new-section .table-bordered td, .content_new-section .table-bordered th {
    border: 1px solid #dee2e6;
    font-size: 14px;
}
.modal-header {
    background-color: #0073b7;
    border-bottom-color: #f4f4f4;
    color: #fff;
    padding: 10px 15px;
    display: block;
}
.form-control{
  margin-bottom: 15px !important;
}

</style>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>QR Codes</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
              <li class="breadcrumb-item active">QR Codes</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
     
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">List of QR Codes</h3>
              </div>
              
              <!-- /.card-header -->
              <div class="card-body">
                <table class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th style="width: 3%">#</th>
                    <th style="width: 10%">BRAND</th>
                    <th style="width: 10%">PRO. SKU</th>
                    <th style="width: 10%">BUYER</th>
                    <th style="width: 15%">STATE</th>
                    <th style="width: 15%">CITY</th>
                    <th style="width: 10%">QR</th>
                    <th style="width: 27%">ACTION</th>
                   
                   
                  </tr>
                  </thead>
                  <tbody>
				  <?php while($resqrcode=fetchAssoc($sqlqr)){

          if($resqrcode['mode'] == 'offline'){
            if($resqrcode['buyer_type'] == 'distributor'){
              $sqlBuyer = exeQuery("SELECT user_id,code,firm,type_og,og_name FROM distributors_new WHERE user_id = '".$resqrcode['buyer_id']."' ");
              $resBuyer = fetchAssoc($sqlBuyer);
              $commn_buyer = $resBuyer['firm'];
            }

            if($resqrcode['buyer_type'] == 'key_account'){
              $sqlBuyer = exeQuery("SELECT id,salon_name,salon_code FROM salons_new WHERE id = '".$resqrcode['buyer_id']."' ");
              $resBuyer = fetchAssoc($sqlBuyer);
              $commn_buyer = $resBuyer['salon_name'];
            }

           
          }

            if($resqrcode['mode'] == 'online'){
              if($resqrcode['buyer_type'] == 'online_portal'){
                $sqlBuyer = exeQuery("SELECT * FROM online_portal WHERE id = '".$resqrcode['buyer_id']."' ");
                $resBuyer = fetchAssoc($sqlBuyer);
                $commn_buyer = $resBuyer['name'];
              }
            }
            
            
            
            ?>
                  <tr>   
                  <td><?php echo $resqrcode['id'] ?></td>        
                    <td><?php echo $resqrcode['brand_name'] ?></td>
                    <td><?php echo $resqrcode['product_sku'] ?></td>  
                    <td>
                      <?php 
                      //if($resqrcode['mode']=='offline'){
                      if(!empty($commn_buyer) && !empty($resqrcode['buyer_type'])){
                      echo $commn_buyer; ?>
                      <div style="font-size:13px">(<span style="font-weight:bold">Type:</span><?php echo $resqrcode['buyer_type'] ?>)</div>
                        <?php } ?>
                        <?php //} ?>
                  </td>  
                  <td><?php echo $resqrcode['state_name'] ?></td>
                  <td><?php echo $resqrcode['city_name'] ?></td>
                  
                  <td><img src="<?php echo $resqrcode['code_url'] ?>" download></td>				
                  <td><!-- <a href="qr_image/<?php //echo $resqrcode['qr_code_image'] ?>" download class="btn btn-success btn-sm btn-flat" style="padding:2px 5px; margin-bottom:2px"><i class="fas fa-download"></i> Download CSV</a> -->
                  <!-- <a href="javascript:void(0)" class="btn btn-success btn-sm btn-flat" style="padding:2px 5px; margin-bottom:2px" onclick="DownloadFile(<?php //echo $resqrcode['id'] ?>)"><i class="fas fa-download"></i> Download CSV</a> -->
                  <a href="javascript:void(0)" data-href="new_scratch_code.php?id=<?=$resqrcode['id']?>" class="btn btn-primary btn-sm btn-flat new_scratch_code" style="padding:2px 5px; margin-bottom:2px"><i class="fas fa-download"></i> Download CSV</a>

                  <a href="view_download_history.php?id=<?php echo $resqrcode['id'] ?>" target="_blank" class="btn btn-warning btn-sm btn-flat" style="padding:2px 5px; margin-bottom:2px"><i class="fas fa-eye"></i> View History</a>

                </td>				
                  </tr>
                  <?php } ?>
                  </tbody>
     
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2021 <a href="#">MAISON D' AURAINE</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.1.0
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->


<!-- Modal -->
<div class="gallery-post">

    <div class="modal fade salon-post bg-none" id="instaPopupModal" tabindex="-1" aria-labelledby="exampleModalLabel"aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <!-- <button type="button" class="close insta-popup" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button> -->
    <div class="modal-dialog modal-lg userpopup">
        <div class="modal-content">
            <div class="modal-body p-0">
            

         <!-- dynamic contents are loaded here don't modify/remove this -->


            </div>
        </div>
    </div>
    </div>

</div>
<!-- Modal end-->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Zebra_datepicker/1.9.12/zebra_datepicker.min.js"></script>

<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="plugins/jszip/jszip.min.js"></script>
<script src="plugins/pdfmake/pdfmake.min.js"></script>
<script src="plugins/pdfmake/vfs_fonts.js"></script>
<script src="plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- Page specific script -->
<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });

  $(document).on('click','.new_scratch_code',function(){
        var dataURL = $(this).attr('data-href');

        $('.modal-body').load(dataURL,function(){
            $('#instaPopupModal').modal({show:true});
            //$('#exampleModal').modal('show');           
        });
    });

    $(document).on('click','.edit_scratch_code',function(){
      //alert('test');return false;
        var dataURL = $(this).attr('data-href');

        $('.modal-body').load(dataURL,function(){
            $('#instaPopupModal').modal({show:true});
            $('#instaPopupModal').modal({backdrop: 'static', keyboard: false})  
            //$('#exampleModal').modal('show');           
        });
    });

    $(document).on('click','.delete_scratch_code',function(){
      //alert('test');return false;
        var dataID = $(this).attr('data-href');
        if(dataID!=''){
          if(confirm('Are you want to delete?')){
            $.ajax({
              type: 'POST',
              url: 'ajaxData.php',
              data: {
                'dataID': dataID
              },
              success: function(data) {
                window.location.reload();
              }
            });
          }
        }

        
    });
</script>

<script>
    function DownloadFile(bundleId){
        var url ="download.php?code="+bundleId;
        var win = window.open(url, '_blank');
        win.focus();
    }
</script>


</body>
</html>
