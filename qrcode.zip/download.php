<?php 
include "library/RF_function.php";
if(isset($_SESSION["user_id"]) == 0){
    header("location:login.php");
 }

    if(isset($_REQUEST['code']) AND $_REQUEST['code']!=""){
        $code=addslashes($_REQUEST['code']);


        /* $sqlbundle=exeQuery("SELECT c.*, b.bundle_code, p.product_sku, p.product_name, p.product_price FROM qr_codes as c
        LEFT JOIN qr_bundle as b ON (c.bundle_id=b.bundle_id) 
        LEFT JOIN products as p ON (p.product_id=b.product_id) 
        WHERE b.bundle_id='".$code."'"); */

        /* echo "SELECT scratch.*,qr.mode,qr.brand_id,qr.product_id,qr.buyer_type,qr.buyer_id,product_name, p.product_sku, p.product_code FROM qr_codes qr
        INNER JOIN scratch_code scratch ON scratch.qr_code_id=qr.id
        LEFT JOIN products as p ON (qr.product_id=p.product_id)
        WHERE qr.id='".$code."' ";

        die; */

        $sqlbundle=exeQuery("SELECT scratch.*,qr.mode,qr.brand_id,qr.product_id,qr.buyer_type,qr.buyer_id,qr.qr_code_image,product_name, p.product_sku, p.product_code FROM qr_codes qr
        INNER JOIN scratch_code scratch ON scratch.qr_code_id=qr.id
        LEFT JOIN products as p ON (qr.product_id=p.product_id)
        WHERE qr.id='".$code."' ");



        $fileName = "QrCode".time().".xls";
        header("Content-Type: application/xls");    
        header("Content-Disposition: attachment; filename=\"$fileName\"");  
        header("Pragma: no-cache"); 
        header("Expires: 0");
        echo '<table border="1">';
        
        echo '<tr style="color:#FFF; height:60px; padding:5px;">
            <th style="background:#030063;">QR Code</th>
            <th style="background:#030063;">Scratch Code</th>
            <th style="background:#030063;">Serial Number</th>
            <th style="background:#030063;">Brand Name</th>
            <th style="background:#030063;">Product SKU</th>
            <th style="background:#030063;">Distributor/Key Account</th>
            <th style="background:#030063;">Created Date</th>
            <th style="background:#030063;">Expire Date</th>
        </tr>';

        


        $numbundle=num_res($sqlbundle);



        if($numbundle>0){
            while($resbundle=fetchAssoc($sqlbundle)){
                echo "<tr>
                    <td>".$resbundle['qr_code_image']."</td>
                    <td>".$resbundle['scratch_code']."</td>
                    <td>".$resbundle['serial_code']."</td>
                    <td>".$resbundle['created_date']."</td>
                    <td>".$resbundle['expire_date']."</td>
                </tr>";
            }
        }else{
            echo "<tr><td colspan='7'>No data Available</td></tr>";
        }
        

        echo "</table>";
    }
     
?>