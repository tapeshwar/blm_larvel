<?php
include "library/RF_function.php";
if(isset($_POST['update_online_portal'])){
    $update_id = addslashes($_REQUEST['update_id']);
    $name = addslashes($_REQUEST['name']);
    $url = addslashes($_REQUEST['portal_url']);
    $desc = addslashes($_REQUEST['desc']);
    $old_image_name = $_REQUEST['old_img'];
    $status = addslashes($_REQUEST['status']);

    if(!empty($_FILES['fil_image'])){
        if(@$_FILES['fil_image']['tmp_name']!=""){
        $set = '';
        $image_name=time().$_FILES['fil_image']['name'];
        if($_FILES['fil_image']['type']=="image/png" or $_FILES['fil_image']['type']=="image/jpeg" or $_FILES['fil_image']['type']=="image/gif"){
            $file_move=move_uploaded_file($_FILES['fil_image']['tmp_name'],"uploads/".$image_name);
            if($file_move){
            $set.=" , logo='".$image_name."'";
            }
            @unlink('uploads/'.$old_image_name);
        }
        }
    }else{
        $set.=" , logo='".$old_image_name."'";
    }
     
    $sqlInsert = exeQuery("UPDATE online_portal SET
		 	name = '".$name."',
			url = '" . $url . "',
            status = '" .$status. "',
            description = '" . $desc . "' $set WHERE id='".$update_id."'
            
            ");
    header('Location:online_portals.php');       
    exit();

}

if(isset($_GET['id'])){
    $id = addslashes($_GET['id']);
    $sqlGetOnlinePortal = exeQuery("SELECT * FROM online_portal WHERE id='".$id."' ORDER BY id ");
    $resRow = fetchAssoc($sqlGetOnlinePortal);
}

?>

<div class="modal-header modal-primary">
    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>Edit Scratch Code 
</div>
<div class="modal-body">
<form action="edit_scratch_code.php" method="post" class="form-horizontal" enctype="multipart/form-data">
    <div class="row">
            <div class="col-sm-8">
                <label class="control-label">Name:</label>
                <input type="text" name="name" value="<?=$resRow['name']?>" class="form-control" placeholder="Name" required data-msg-required="Name is required"> 
            </div>
        
            <div class="col-sm-8">
                <label class="control-label">Portal URL:</label>
                <input type="text" name="portal_url" value="<?=$resRow['url']?>" class="form-control" placeholder="Portal URL">
            </div>
            <div class="col-sm-8">
                <label class="control-label">Logo:</label>
                <input type="file" class="form-control" name="fil_image">
                <?php
                if(!empty($resRow['logo'])){ ?>
                    <img src="uploads/<?=$resRow['logo']?>" height="100">
                <?php }
                ?>
                <input type="hidden" name="old_img" value="<?=$resRow['logo']?>">
            </div>

            <div class="col-sm-8">
                <label class="control-label">Description:</label>
                <textarea name="desc" class="form-control"><?=$resRow['description']?></textarea>
            </div>

            <div class="col-sm-6">
                <label class="control-label">Status:</label>
                <select name="status" class="form-control">
                    <option value="1" <?php if($resRow['status'] == 1) {?> selected <?php } ?>>Enabled</option>
                    <option value="0" <?php if($resRow['status'] == 0) {?> selected <?php } ?>>Disabled</option>
                </select>
            </div>


        <div class="col-md-8" style="margin-top: 20px;">   
        <input type="hidden" name="update_id" value="<?=$resRow['id']?>">   
            <button type="submit" name="update_scratch_code" class="btn btn-primary btn-md btn-flat ">Update</button>
        </div>

    </div>
    </form>
</div>