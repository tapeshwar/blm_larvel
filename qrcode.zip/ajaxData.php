<?php
//Include database configuration file
include "library/RF_function.php";

//===============State=================

if(isset($_POST["zone_id"]) && !empty($_POST["zone_id"])){
    //Get all city data
    $query = exeQuery("SELECT * FROM states WHERE region_id = ".$_POST['zone_id']." AND status = 1 ORDER BY state_id ASC");
    //Count total number of rows
    $rowCount = num_res($query);
    //Display cities list
    if($rowCount > 0){
        echo '<option value="">--Select state--</option>';
        while($row = fetchAssoc($query)){ 
            echo '<option value="'.$row['state_id'].'">'.$row['state_name'].'</option>';
        }
    }else{
        echo '<option value="">State not available</option>';
    }
}


//===============City=================

if(isset($_POST["state_id"]) && !empty($_POST["state_id"])){
    //Get all city data
    $query = exeQuery("SELECT * FROM cities WHERE state_id = ".$_POST['state_id']." AND status = 1 ORDER BY city_name ASC");
    //Count total number of rows
    $rowCount = num_res($query);
    //Display cities list
    if($rowCount > 0){
        echo '<option value="">--Select city--</option>';
        while($row = fetchAssoc($query)){ 
            echo '<option value="'.$row['city_id'].'">'.$row['city_name'].'</option>';
        }
    }else{
        echo '<option value="">City not found</option>';
    }
}


if(isset($_POST["brand_id"]) && !empty($_POST["brand_id"])){
    //Get all city data
    $query = exeQuery("SELECT * FROM products WHERE brand_id = ".$_POST['brand_id']." AND status = 1 ORDER BY product_id ASC");
    //Count total number of rows
    $rowCount = num_res($query);
    //Display cities list
    if($rowCount > 0){
        echo '<option value="">--Select Product--</option>';
        while($row = fetchAssoc($query)){ 
            echo '<option value="'.$row['product_id'].'">'.$row['product_name'].'</option>';
        }
    }else{
        echo '<option value="">Product not found</option>';
    }
}

if(isset($_POST["buyer_type"]) && !empty($_POST["buyer_type"])){

    $erpBrand = $_POST['erpBrand'];
    $erpZone = $_POST['erpZone'];
    $erpState = $_POST['erpState'];
    $erpCity = $_POST['erpCity'];

    if($_POST['buyer_type'] == 'distributor'){
        $lable = 'Distributor';
        //echo "SELECT * FROM distributors_new WHERE region = '".$erpZone."' AND state = '".$erpState."' AND city = '".$erpCity."' AND p_brand_id LIKE '%$erpBrand%' AND status = 1 ORDER BY user_id ASC";
        $query = exeQuery("SELECT * FROM distributors_new WHERE region = '".$erpZone."' AND state = '".$erpState."' AND city = '".$erpCity."' AND p_brand_id LIKE '%$erpBrand%' AND status = 1 ORDER BY user_id ASC");
    }
    if($_POST['buyer_type'] == 'key_account'){  
        $lable = 'Key account';
        //echo "SELECT * FROM salons_new WHERE salon_type = 'Key Account' AND region = '".$erpZone."' AND state = '".$erpState."' AND city = '".$erpCity."' AND product_brand = '".$erpBrand."' AND status = 1 ORDER BY id ASC";
        $query = exeQuery("SELECT * FROM salons_new WHERE salon_type = 'Key Account' AND region = '".$erpZone."' AND state = '".$erpState."' AND city = '".$erpCity."' AND product_brand = '".$erpBrand."' AND status = 1 ORDER BY id ASC");
    }
    //Get all city data
    
    //Count total number of rows
    $rowCount = num_res($query);
    //Display cities list
    if($rowCount > 0){
        echo '<option value="">--Select '.$lable.'--</option>';
        if($_POST['buyer_type'] == 'distributor'){
            while($row = fetchAssoc($query)){ 
                echo '<option value="'.$row['user_id'].'">'.$row['og_name'].'</option>';
            }
        }

        if($_POST['buyer_type'] == 'key_account'){
            while($row = fetchAssoc($query)){ 
                echo '<option value="'.$row['id'].'">'.$row['salon_name'].'</option>';
            }
        }

    }else{
        echo '<option value="">'.$lable.' not found</option>';
    }
}


if(isset($_POST["dataID"]) && !empty($_POST["dataID"])){
    //Get all city data
    $query = exeQuery("DELETE FROM online_portal WHERE id = ".$_POST['dataID']." ");
    
}

?>