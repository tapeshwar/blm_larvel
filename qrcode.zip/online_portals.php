<?php 
 include "library/RF_function.php";

	if(isset($_SESSION["user_id"]) == 0){
	   header("location:login.php");
	}
	$sqlGetOnline=exeQuery("SELECT * FROM online_portal ORDER BY id ASC ");
		
?>
<?php include "include/header.php";?>
<?php include "include/sidebar.php";


?>

<style>
.content_new-section .table-bordered td, .content_new-section .table-bordered th {
    border: 1px solid #dee2e6;
    font-size: 14px;
}
.modal-header {
    background-color: #0073b7;
    border-bottom-color: #f4f4f4;
    color: #fff;
    padding: 10px 15px;
    display: block;
}
.form-control{
  margin-bottom: 15px !important;
}

</style>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Online Portal</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
              <li class="breadcrumb-item active">Online Portal</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">List Online Portal</h3>
              </div>

              <div class="row">
                <div class="col-md-12" style="padding:20px 0px 0px 30px">
                  <!-- <button class="btn btn-sm btn-primary" >Create New</button> -->
                  <a href="javascript:void(0)" data-href="add_online_portal.php" class="btn btn-sm btn-primary comment add_online_portal">Create New</a>
                </div>
                 
                
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Logo</th>
                    <th>Status</th>
                    <th>Action</th>
                   
                   
                  </tr>
                  </thead>
                  <tbody>
				        <?php while($resOnline=fetchAssoc($sqlGetOnline)){ ?>
                  <tr>
                  <td><?php echo $resOnline['id'] ?></td>               
                    <td><?php echo $resOnline['name'] ?></td>
                    <td>
                      <?php if(!empty($resOnline['logo'])) {?>
                        <img src="uploads/<?=$resOnline['logo']?>" height="50">
                    <?php } ?>
                    </td>
                    <td>
                      <?php 
                      if($resOnline['status'] == 1) {?>
                      <button class="btn btn-xs btn-success">Enabled</button>
                      <?php } ?>
                      <?php if($resOnline['status'] == 0) {?>
                      <button class="btn btn-xs btn-danger">Disbled</button>
                      <?php } ?>
                    </td>  				
					          <td>
                      <a class="btn btn-sm btn-primary edit_online_portal" href="javascript:void(0)" data-href="edit_online_portal.php?id=<?=$resOnline['id']?>"><i class="fas fa-pen"></i></a>
                      <a class="btn btn-sm btn-danger delete_online_portal" href="javascript:void(0)" data-href="<?=$resOnline['id']?>"><i class="fas fa-trash"></i></a>
                  </td>				
                  </tr>
                  <?php } ?>
                  </tbody>
     
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2021 <a href="#">MAISON D' AURAINE</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.1.0
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->


<!-- Modal -->
<div class="gallery-post">

    <div class="modal fade salon-post bg-none" id="instaPopupModal" tabindex="-1" aria-labelledby="exampleModalLabel"aria-hidden="true">
    <!-- <button type="button" class="close insta-popup" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button> -->
    <div class="modal-dialog modal-lg userpopup">
        <div class="modal-content">
            <div class="modal-body p-0">
            

         <!-- dynamic contents are loaded here don't modify/remove this -->


            </div>
        </div>
    </div>
    </div>

</div>
<!-- Modal end-->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="plugins/jszip/jszip.min.js"></script>
<script src="plugins/pdfmake/pdfmake.min.js"></script>
<script src="plugins/pdfmake/vfs_fonts.js"></script>
<script src="plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- Page specific script -->
<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });



  $(document).on('click','.add_online_portal',function(){
        var dataURL = $(this).attr('data-href');

        $('.modal-body').load(dataURL,function(){
            $('#instaPopupModal').modal({show:true});
            //$('#exampleModal').modal('show');           
        });
    });

    $(document).on('click','.edit_online_portal',function(){
      //alert('test');return false;
        var dataURL = $(this).attr('data-href');

        $('.modal-body').load(dataURL,function(){
            $('#instaPopupModal').modal({show:true});
            //$('#exampleModal').modal('show');           
        });
    });

    $(document).on('click','.delete_online_portal',function(){
      //alert('test');return false;
        var dataID = $(this).attr('data-href');
        if(dataID!=''){
          if(confirm('Are you want to delete?')){
            $.ajax({
              type: 'POST',
              url: 'ajaxData.php',
              data: {
                'dataID': dataID
              },
              success: function(data) {
                window.location.reload();
              }
            });
          }
        }

        
    });

    
</script>


</body>
</html>
