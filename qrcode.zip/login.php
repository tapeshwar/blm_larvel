<?php 
 include "library/RF_function.php";

if(isset($_SESSION["user_id"])){
   header("location:index.php");
}

if(isset($_REQUEST['subLogin'])){
    $txt_username=addslashes($_POST['txt_username']);
    $txt_password=addslashes($_POST['txt_password']);
  
    //$encryptedPass=base64_encode(convert_uuencode($txt_password));
    
    $sqlLogin = "SELECT * FROM users WHERE email='".$txt_username."' AND password='".$txt_password."' AND status='1'";
    $resLogin = exeQuery($sqlLogin);    
    if($rowLogin = fetchAssoc($resLogin)){
		
        $_SESSION["errorType"] = "success";
        $_SESSION["errorMsg"] = "You have successfully logged in.";
        $_SESSION["user_id"] = $rowLogin["user_id"];
        $_SESSION["username"] = $rowLogin["name"];
        $_SESSION["useremail"] = $rowLogin["email"];
        $currentTime=date("Y-m-d H:i:s");
   
        if($rowLogin){
            $_SESSION['alert_msg'] = "You have been logged in successfully ---!!!";
            $_SESSION['alert_type'] = "success";
            header("location:index.php");
        }else{
            $_SESSION['alert_msg'] = "Something went wrong please try again";
            $_SESSION['alert_type'] = "danger";
        }
    }else{
        $_SESSION['alert_msg'] = "The username & password provided by you is incorrect.";
        $_SESSION['alert_type'] = "danger";
    }

} 
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>MAISON D' AURAINE</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
</head>
<body class="hold-transition login-page">
<div class="login-box">
  <!-- /.login-logo -->
  <div class="card card-outline card-primary">
    <div class="card-header text-center">
      <a href="javascript:voide(0)" class="h4"><b>MAISON D'</b>AURAINE</a>
    </div>
    <div class="card-body">
      <p class="login-box-msg">Sign in to start your session</p>

      <form action="" method="post">
	     <?php
			if(isset($_SESSION['alert_msg'])){
				echo "<div class='card bg-danger'>
					 <div class='card-body'>
					<strong>Error!</strong> ".$_SESSION['alert_msg']."
				  </div></div><br>";  
				unset($_SESSION['alert_msg']);
				unset($_SESSION['alert_type']);
			}
		  ?>

			
        <div class="input-group mb-3">
          <input type="email" name="txt_username" class="form-control" placeholder="Enter your email">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-envelope"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password" name="txt_password" class="form-control" placeholder="Enter your password">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-8">
            <div class="icheck-primary">
              <input type="checkbox" id="remember">
             
            </div>
          </div>
          <!-- /.col -->
          <div class="col-4">
		  <button class="btn btn-primary btn-block" type="submit" name="subLogin">Sign In</button>
          </div>
          <!-- /.col -->
        </div>
      </form>


      <!-- /.social-auth-links -->

      <!--<p class="mb-1">
        <a href="forgot-password.html">I forgot my password</a>
      </p>
      <p class="mb-0">
        <a href="register.html" class="text-center">Register a new membership</a>
      </p>-->
    </div>
    <!-- /.card-body -->
  </div>
  <!-- /.card -->
</div>
<!-- /.login-box -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
</body>
</html>
