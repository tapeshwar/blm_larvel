<?php

//Get Geocode
            $url = "https://www.googleapis.com/geolocation/v2/geolocate?key=AIzaSyCKujbP3gEUfWWA8Igiw7wGUE2KsuCfaVc";
            
            /*$ch  = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
  $data = curl_exec($ch);
  curl_close($ch);
  */
            
            $data = ['collection' => 'RapidAPI'];
            $curl = curl_init($url);
            //curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS,  json_encode($data));
            curl_setopt($curl, CURLOPT_HTTPHEADER, [
              'X-RapidAPI-Host: kvstore.p.rapidapi.com',
              'X-RapidAPI-Key: AIzaSyCKujbP3gEUfWWA8Igiw7wGUE2KsuCfaVc',
              'Content-Type: application/json'
            ]);
            $response = curl_exec($curl);
            curl_close($curl);
            $getLoc = json_decode($response, true);
            print_r($getLoc);
            //echo $lat = $getLoc['location']['lat'];
            //echo $lng = $getLoc['location']['lng'];
            
            $lat = '28.5057948';
            $lng = '77.06794769999999';




?>

<?php
// A sample PHP Script to POST data using cURL
// Data in JSON format

$data = ['collection' => 'RapidAPI'];

$payload = json_encode($data);

// Prepare new cURL resource
//$ch = curl_init('https://api.example.com/api/1.0/user/login');
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLINFO_HEADER_OUT, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);

// Set HTTP Header for POST request 

curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'X-RapidAPI-Host: kvstore.p.rapidapi.com',
    'X-RapidAPI-Key: AIzaSyCKujbP3gEUfWWA8Igiw7wGUE2KsuCfaVc',
    'Content-Type: application/json',
    'Content-Length: ' . strlen($payload))
);

// Submit the POST request
$result = curl_exec($ch);

// Close cURL session handle
curl_close($ch);
print_r($result);
?>
