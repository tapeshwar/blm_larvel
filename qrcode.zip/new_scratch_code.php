<?php
include "library/RF_function.php";
//include "include/header.php";
if(isset($_GET['id'])){
    $id = addslashes($_GET['id']);
}

if(isset($_POST['store_scratch_code'])){
    $qr_code_id = addslashes($_REQUEST['qr_code_id']);
    $qty = addslashes($_REQUEST['qty']);

    $sql_qr = exeQuery("SELECT qc.*, c.city_name, s.state_name,b.brand_name,p.product_name, p.product_sku, p.product_code FROM qr_codes as qc 
    LEFT JOIN brands as b ON (b.brand_id=qc.brand_id ) 
    LEFT JOIN cities as c ON (c.city_id=qc.city_id) 
    LEFT JOIN states as s ON (s.state_id=qc.state_id) 
    LEFT JOIN products as p ON (p.product_id=qc.product_id)
    WHERE qc.id = $qr_code_id LIMIT 1");
    $resqrcode = fetchAssoc($sql_qr);

    if($resqrcode['mode'] == 'offline'){
        if($resqrcode['buyer_type'] == 'distributor'){
          $sqlBuyer = exeQuery("SELECT user_id,code,firm,type_og,og_name FROM distributors_new WHERE user_id = '".$resqrcode['buyer_id']."' ");
          $resBuyer = fetchAssoc($sqlBuyer);
          $commn_buyer = $resBuyer['firm'];
        }

        if($resqrcode['buyer_type'] == 'key_account'){
          $sqlBuyer = exeQuery("SELECT id,salon_name,salon_code FROM salons_new WHERE id = '".$resqrcode['buyer_id']."' ");
          $resBuyer = fetchAssoc($sqlBuyer);
          $commn_buyer = $resBuyer['salon_name'];
        }

      }

        if($resqrcode['mode'] == 'online'){
          if($resqrcode['buyer_type'] == 'online_portal'){
            $sqlBuyer = exeQuery("SELECT * FROM online_portal WHERE id = '".$resqrcode['buyer_id']."' ");
            $resBuyer = fetchAssoc($sqlBuyer);
            $commn_buyer = $resBuyer['name'];
          }
        }

        //echo $commn_buyer;die;

    $sql_sno = exeQuery("SELECT serial_no FROM scratch_code ORDER BY serial_no DESC LIMIT 1");
    $getSno = fetchAssoc($sql_sno);



    if(!empty($getSno['serial_no'])){
        $sno = $getSno['serial_no'];
    }else{
        $sno = 0;
    } 



    
    //$status = addslashes($_REQUEST['status']);
    $created_date = date('Ymd');
    $expire_date = $_REQUEST['expire_date'];
    //$expire_date = date("Y-m-d", strtotime($expire_date));
    
    $updated_on = date('YmdHis');

    $logSql = "INSERT INTO qr_code_download_log SET
    qr_code_id = '".$qr_code_id."',
    qty = '" . $qty . "',
    download_date = '".$updated_on."' ";
    
    $inserted_id = inserted_id($logSql);


    if(!empty($qty)){
        for($i=1;$i<=$qty;$i++){

            $tsno = $sno+$i;
            //$number = sprintf('%06d', $tsno);
            $number = str_pad($tsno, 7, "0", STR_PAD_LEFT);
            $srcode = strtoupper(substr($resqrcode['brand_name'],0,2).substr($resqrcode['state_name'],0,3).substr($resqrcode['mode'],0,2).substr($resqrcode['buyer_type'],0,3).substr($commn_buyer,0,3)).$tsno;

            $unique = strtoupper(substr(md5(str_shuffle(str_repeat("0123456789", 8))), 0, 8));
            $scratch_code = $unique;
            exeQuery("INSERT INTO scratch_code SET
                qr_code_id = '".$qr_code_id."',
                scratch_code = '" . $scratch_code . "',
                serial_code = '" . $srcode . "',
                serial_no = '" . $number . "',
                status = 1,
                log_id = '".$inserted_id."',
                created_date = '".$created_date."',
                expire_date = '".$expire_date."',
                updated_on = '" . $updated_on . "'
           
           ");

        }
    }


    $code = $qr_code_id;

    /* echo "SELECT scratch.*,qr.mode,qr.brand_id,qr.product_id,qr.buyer_type,qr.buyer_id,qr.qr_code_image,p.product_name, p.product_sku, p.product_code FROM scratch_code scratch 
    INNER JOIN qr_codes qr ON scratch.qr_code_id=qr.id
    LEFT JOIN products as p ON (qr.product_id=p.product_id)
    WHERE scratch.qr_code_id='".$code."' AND scratch.status = 1 ORDER BY scratch.id DESC LIMIT $qty ";  

    die; */ 

    $sqlbundle=exeQuery("SELECT scratch.*,qr.mode,qr.brand_id,qr.product_id,qr.buyer_type,qr.buyer_id,qr.qr_code_image,p.product_name, p.product_sku, p.product_code FROM scratch_code scratch 
    INNER JOIN qr_codes qr ON scratch.qr_code_id=qr.id
    LEFT JOIN products as p ON (qr.product_id=p.product_id)
    WHERE scratch.qr_code_id='".$code."' AND scratch.log_id = '".$inserted_id."' AND scratch.status = 1 ORDER BY scratch.id DESC LIMIT $qty ");



        $fileName = "QrCode".time().".xls";
        header("Content-Type: application/xls");    
        header("Content-Disposition: attachment; filename=\"$fileName\"");  
        header("Pragma: no-cache"); 
        header("Expires: 0");
        echo '<table border="1">';
        
        echo '<tr style="color:#FFF; height:60px; padding:5px;">
            <th style="background:#030063;">QR Code</th>
            <th style="background:#030063;">Scratch Code</th>
            <th style="background:#030063;">Serial Number</th>
        </tr>';

        


        $numbundle=num_res($sqlbundle);

        if($numbundle>0){
            while($resbundle=fetchAssoc($sqlbundle)){
                echo "<tr>
                    <td>".base_url().'qr_image/'.$resbundle['qr_code_image']."</td>
                    <td>".$resbundle['scratch_code']."</td>
                    <td>".$resbundle['serial_code']."</td>
                </tr>";
            }
        }else{
            echo "<tr><td colspan='7'>No data Available</td></tr>";
        }
        echo "</table>";


        


    //header('Location:qrcodes.php');       
    exit();

}





?>

<div class="modal-header modal-primary">
    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>Download QR Code 
</div>
<div class="modal-body">
<form id="add_module_form" action="new_scratch_code.php" method="post" class="form-horizontal" enctype="multipart/form-data">
    <div class="row">
        
             <div class="col-sm-8">
                <label class="control-label">No. of Quantity:</label>
                <input type="text" name="qty" class="form-control" value="1" placeholder="Quantity">
            </div>
            <!--<div class="col-sm-8">
                <label class="control-label">Logo:</label>
                <input type="file" class="form-control" name="fil_image">
            </div>-->

            <div class="col-sm-8">
                <label class="control-label">Expire Date:</label>
                <input type="text" name="expire_date" class="form-control datepicker">   
            </div>

            <!-- <div class="col-sm-6">
                <label class="control-label">Status:</label>
                <select name="status" class="form-control">
                    <option value="1">Active</option>
                    <option value="0">Inactive</option>
                </select>
            </div> -->


        <div class="col-md-8" style="margin-top: 20px;">  
        <input type="hidden" name="qr_code_id" value="<?=$id?>" >    
            <button type="submit" name="store_scratch_code" class="btn btn-primary btn-md btn-flat store_module_btn">Download</button>
        </div>

    </div>
    </form>
</div>
<script>
  $(document).ready(function() {
    $('.datepicker').Zebra_DatePicker({
        direction: 1
    });
    $('.close').click(function(){
        window.location.reload();
    })
  });
</script>

