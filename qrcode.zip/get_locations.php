<?php
session_start();
$test = $_SESSION['getlat'] = $_POST['latitude'];
$_SESSION['getlong'] = $_POST['longitude'];
?>