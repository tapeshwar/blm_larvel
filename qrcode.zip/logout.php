<?php 
include "library/RF_function.php";

unset($_SESSION['user_id']);
unset($_SESSION['username']);
unset($_SESSION['useremail']);

session_destroy();
header("location:login.php");

?>