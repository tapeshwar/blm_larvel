<?php 
 include "library/RF_function.php";

	if(isset($_SESSION["user_id"]) == 0){
	   header("location:login.php");
	}
	$sqlGetOnline=exeQuery("SELECT scratch.*,qr.mode,qr.brand_id,qr.product_id,qr.buyer_type,qr.buyer_id,product_name, p.product_sku, p.product_code FROM scratch_code scratch 
  INNER JOIN qr_codes qr ON scratch.qr_code_id=qr.id
  LEFT JOIN products as p ON (qr.product_id=p.product_id)
  ORDER BY scratch.id DESC ");
		
?>
<?php include "include/header.php";?>
<?php include "include/sidebar.php";


?>

<style>
.content_new-section .table-bordered td, .content_new-section .table-bordered th {
    border: 1px solid #dee2e6;
    font-size: 14px;
}
.modal-header {
    background-color: #0073b7;
    border-bottom-color: #f4f4f4;
    color: #fff;
    padding: 10px 15px;
    display: block;
}
.form-control{
  margin-bottom: 15px !important;
}
td.table-bgs span {
    background: #ddd;
    padding: 0px 10px;
    border: 1px solid #0000001f;
    color: #00000040;
}
</style>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Scratch Code</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
              <li class="breadcrumb-item active">Scratch Code</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
        
          <div class="col-md-12">
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">List of Scratch Code</h3>
              </div>

              <div class="row">
                <!-- <div class="col-md-12" style="padding:20px 0px 0px 30px">
                  <a href="javascript:void(0)" data-href="new_scratch_code.php" class="btn btn-sm btn-primary comment new_scratch_code">Create New</a>
                </div> -->
                 
                
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example123" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>#</th>
                    
                    <th>SCRATCH CODE</th>
                    <th>SERIAL CODE</th>
                    <th>SERIAL NO.</th>
                    <th>BUYER</th>
                    <th>PRO. SKU</th>
                    <th>STATUS</th>
                   
                   
                  </tr>
                  </thead>
                  <tbody>
				        <?php while($resScratch=fetchAssoc($sqlGetOnline)){ 
                  
                  if($resScratch['mode'] == 'offline'){
                    if($resScratch['buyer_type'] == 'distributor'){
                      $sqlBuyer = exeQuery("SELECT user_id,code,firm,type_og,og_name FROM distributors_new WHERE user_id = '".$resScratch['buyer_id']."' ");
                      $resBuyer = fetchAssoc($sqlBuyer);
                      $commn_buyer = $resBuyer['firm'];
                    }
        
                    if($resScratch['buyer_type'] == 'key_account'){
                      $sqlBuyer = exeQuery("SELECT id,salon_name,salon_code FROM salons_new WHERE id = '".$resScratch['buyer_id']."' ");
                      $resBuyer = fetchAssoc($sqlBuyer);
                      $commn_buyer = $resBuyer['salon_name'];
                    }
        
                    
                  }
        
                    if($resScratch['mode'] == 'online'){
                      if($resScratch['buyer_type'] == 'online_portal'){
                        $sqlBuyer = exeQuery("SELECT * FROM online_portal WHERE id = '".$resScratch['buyer_id']."' ");
                        $resBuyer = fetchAssoc($sqlBuyer);
                        $commn_buyer = $resBuyer['name'];
                      }
                    }
                  
                  ?>
                  <tr>
                  <td><?php echo $resScratch['id'] ?></td>               
                    
                    <td class="table-bgs">
                     <span> <?=$resScratch['scratch_code']?></span>
                    </td>
                    <td><?php echo $resScratch['serial_code'] ?></td>
                    <td><?php echo $resScratch['serial_no'] ?></td>
                    <td><?php 
                      if(!empty($commn_buyer) && !empty($resScratch['buyer_type'])){
                      echo $commn_buyer; ?>
                      <div style="font-size:13px">(<span style="font-weight:bold">Type:</span><?php echo $resScratch['buyer_type'] ?>)</div>
                        <?php } ?>
                      </td>
                    <td><?=$resScratch['product_sku']?></td>
                    <td>
                      <?php 
                      if($resScratch['status'] == 1) {?>
                      <button class="btn btn-xs btn-success">Active</button>
                      <?php } ?>
                      <?php if($resScratch['status'] == 0) {?>
                      <button class="btn btn-xs btn-danger">Inactive</button>
                      <?php } ?>
                    </td>  				
					          			
                  </tr>
                  <?php } ?>
                  </tbody>
     
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2021 <a href="#">MAISON D' AURAINE</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.1.0
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->


<!-- Modal -->
<div class="gallery-post">

    <div class="modal fade salon-post bg-none" id="instaPopupModal" tabindex="-1" aria-labelledby="exampleModalLabel"aria-hidden="true">
    <!-- <button type="button" class="close insta-popup" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button> -->
    <div class="modal-dialog modal-lg userpopup">
        <div class="modal-content">
            <div class="modal-body p-0">
            

         <!-- dynamic contents are loaded here don't modify/remove this -->


            </div>
        </div>
    </div>
    </div>

</div>
<!-- Modal end-->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>



<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="plugins/jszip/jszip.min.js"></script>
<script src="plugins/pdfmake/pdfmake.min.js"></script>
<script src="plugins/pdfmake/vfs_fonts.js"></script>
<script src="plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- Page specific script -->
<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });



  $(document).on('click','.new_scratch_code',function(){
        var dataURL = $(this).attr('data-href');

        $('.modal-body').load(dataURL,function(){
            $('#instaPopupModal').modal({show:true});
            //$('#exampleModal').modal('show');           
        });
    });

    $(document).on('click','.edit_scratch_code',function(){
      //alert('test');return false;
        var dataURL = $(this).attr('data-href');

        $('.modal-body').load(dataURL,function(){
            $('#instaPopupModal').modal({show:true});
            //$('#exampleModal').modal('show');           
        });
    });

    $(document).on('click','.delete_scratch_code',function(){
      //alert('test');return false;
        var dataID = $(this).attr('data-href');
        if(dataID!=''){
          if(confirm('Are you want to delete?')){
            $.ajax({
              type: 'POST',
              url: 'ajaxData.php',
              data: {
                'dataID': dataID
              },
              success: function(data) {
                window.location.reload();
              }
            });
          }
        }

        
    });

    
</script>



<!-- <script src="plugins/jquery/jquery.min.js"></script> -->



</body>
</html>
