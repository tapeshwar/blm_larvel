<?php
include "library/RF_function.php";

if (isset($_SESSION["user_id"]) == 0) {
  header("location:login.php");
}
//Generate Qr code
if (isset($_REQUEST['generateQR'])) {
//echo '<pre>';
//print_r($_REQUEST);die;
  $mode = addslashes($_REQUEST['mode']);
  $brand = addslashes($_REQUEST['brand']);
  $product = addslashes($_REQUEST['product']);
  $buyer_type = addslashes($_REQUEST['buyer_type']);
  $online_buyer = addslashes($_REQUEST['online_buyer']);
  $buyer = addslashes($_REQUEST['buyer']);
  $region = addslashes($_REQUEST['region']);
  $state = addslashes($_REQUEST['state']);
  $city = addslashes($_REQUEST['city']);
  $validate = addslashes($_REQUEST['validate']);
  $createdon = date('Y-m-d H:i:s');
  $sqlins = "";

  $unique = strtoupper(substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz", 4)), 0, 4));
  $uniqueCode = time() . '' . $unique . '' . RAND(10000, 99999);
  $codeenc = urlencode(base64_encode($uniqueCode));
  //$uniqURL=BASE_URL.'verify.php?uq='.$codeenc;
  $uniqURL = BASE_URL . '?q=' . $unique;
  $longurl = BASE_URL . 'verify.php?uq=' . $codeenc;

  //echo "--";
  //echo $codeenc1 = base64_decode(urldecode($codeenc));
  $qrcodeURL = "https://chart.googleapis.com/chart?cht=qr&chs=250x250&chl=" . $uniqURL . "&choe=UTF-8";
  //echo $qrcodeURL;die;
  $imageName = time() . '.png';
  qrCode(250, $imageName, $uniqURL);

  if($mode == 'offline'){
  		$sqlins .= "INSERT INTO qr_codes SET
		 	mode = 'offline',
			brand_id='" . $brand . "',
			product_id='" . $product . "',
			buyer_type='" . $buyer_type . "',
			buyer_id='" . $buyer . "',
			region = '".$region."',
			state_id='" . $state . "',
			city_id='" . $city . "',
			unique_code='" . $uniqueCode . "',
			short_url='" . $uniqURL . "',
			s_code='" . $unique . "',
			unique_url='" . $longurl . "',
			code_url='" . $qrcodeURL . "',
			qr_code_image='" . $imageName . "',
			validate_with='" . $validate . "',
			final_status='1',
			updated_on='" . $createdon . "';";
  }

  if($mode == 'online'){
	$sqlins .= "INSERT INTO qr_codes SET
	mode = 'online',
	brand_id='" . $brand . "',
	product_id='" . $product . "',
	buyer_type='online_portal',
	buyer_id='" . $online_buyer . "',
	region = '0',
	state_id='0',
	city_id='0',
	unique_code='" . $uniqueCode . "',
	short_url='" . $uniqURL . "',
	s_code='" . $unique . "',
	unique_url='" . $longurl . "',
	code_url='" . $qrcodeURL . "',
	qr_code_image='" . $imageName . "',
	validate_with='0',
	final_status='1',
	updated_on='" . $createdon . "';";
  }
  $executed = multiQuery($sqlins);


  if ($executed) {
    $_SESSION['sess_msg'] = "The QR Code has been generated successfully!";
    $_SESSION['types'] = "success";
  } else {
    $_SESSION['sess_msg'] = "Something went wrong with the system please try after sometimes or contact to IT Department!";
    $_SESSION['types'] = "danger";
  }
  header("Location:qrcodes.php");
  exit();
}

//Generate QR Code Image
function qrCode($size = 250, $filename = null, $uniqURL)
{
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, 'http://chart.apis.google.com/chart');
  curl_setopt($ch, CURLOPT_POST, true);
  curl_setopt($ch, CURLOPT_POSTFIELDS, "chs={$size}x{$size}&cht=qr&chl=" . $uniqURL);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_TIMEOUT, 30);
  $img = curl_exec($ch);
  curl_close($ch);

  if ($img) {
    if ($filename) {
      if (!preg_match("#\.png#i", $filename)) {
        $filename .= ".png";
      }
      $path = "qr_image/" . $filename;
      return file_put_contents($path, $img);
    } else {
      header("Content-type: image/png");
      //print $img;
      return true;
    }
  }
  return false;
}

include "include/header.php";
include "include/sidebar.php";


$sqlbrand = exeQuery("select brand_id,brand_name from brands where status='1' ORDER BY brand_name");
//$sqlstate = exeQuery("select state_id,state_name from states where status='1' ORDER BY state_name");
$sqlZone = exeQuery("SELECT * FROM regions WHERE status='1'");
$sqlOnlinePortal = exeQuery("SELECT * FROM online_portal WHERE status='1'");
//$resbrand=fetchAssoc($sqlstate);

?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Create Code</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Create Code</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <!-- left column -->
        <div class="col-md-6">
          <!-- jquery validation -->
          <div class="card card-primary">
            <!--<div class="card-header">
                <h3 class="card-title">Create QR code <small></small></h3>
              </div>-->
            <!-- /.card-header -->
            <!-- form start -->
            <form method="post" id="qrcode_form">
              <div class="card-body">

				  	<div class="form-group">
                  
						<span class="radio">
                    <label for="offline">
                    <input type="radio" id="offline" name="mode" value="offline" checked>
                     Offline</label>
                  </span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<span class="radio">
                    <label for="online">
                    <input type="radio" id="online" name="mode" value="online">
                     Online</label>
                  </span>  
               </div>


                <div class="form-group">
                  <label for="">Brand</label>
                  <select name="brand" class="form-control" id="erpBrand">
                    <option value="">--Select Brand--</option>
                    <?php while ($resbrand = fetchAssoc($sqlbrand)) { ?>
                      <option value="<?php echo $resbrand['brand_id']; ?>"><?php echo $resbrand['brand_name']; ?></option>
                    <?php } ?>
                  </select>
                </div>

					 <div class="form-group">
                  <label for="product">Products</label>
                  <select name="product" id="product" class="form-control">
                    <option value="">--Select Product--</option>
                  </select>
                </div>

					 <div id="online_mode" style="display: none;">
					 <div class="form-group">
					 <label for="customer">Online Portal</label>
                  <select name="online_buyer" id="online_buyer" class="form-control">
                    <option value="">--Online Portal--</option>
						  <?php while ($resOnline = fetchAssoc($sqlOnlinePortal)) { ?>
                      <option value="<?php echo $resOnline['id']; ?>"><?php echo $resOnline['name']; ?></option>
                    <?php } ?>
						  <!-- <option value="1">Amazone</option>
						  <option value="2">GKHair</option>
						  <option value="3">Glamour Book</option> -->

                  </select>
                </div>
					 </div>

					<div id="offline_mode">
					 <div class="form-group">
                  <label for="">Zone</label>
                  <select name="region" class="form-control" id="erpZone">
                    <option value="">--Select Zone--</option>
                    <?php while ($resZone = fetchAssoc($sqlZone)) { ?>
                      <option value="<?php echo $resZone['region_id']; ?>"><?php echo $resZone['region_name']; ?></option>
                    <?php } ?>
                  </select>
                </div>

					 <div class="form-group">
                  <label for="">State</label>
                  <select name="state" id="state" class="form-control">
                    <option value="">--Select State--</option>
                    <?php /*while ($resstate = fetchAssoc($sqlstate)) { ?>
                      <option value="<?php echo $resstate['state_id']; ?>"><?php echo $resstate['state_name']; ?></option>
                    <?php } */?>
                  </select>
                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1">City</label>
                  <select name="city" id="city" class="form-control">
                    <option value="">--Select City--</option>
                  </select>
                </div>

					 <div class="form-group">
                  <span class="radio">
						<span class="radio">
                    <label for="distribtr">
                    <input type="radio" id="distribtr" name="buyer_type" value="distributor">
                     Distributor</label>
                  </span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

                    <label for="key_acnt">
                    <input type="radio" id="key_acnt" name="buyer_type" value="key_account">
                     Key Account</label>
                  </span> 
                  
                  
                </div>

                <div class="form-group">
					 <label for="customer">Buyers</label>
                  <select name="buyer" id="buyer_type" class="form-control">
                    <option value="">--Select Buyers--</option>
                  </select>
                </div>

                
                <div class="form-group">
                  <label for="exampleInputEmail1">Geofencing</label>
                  <select name="validate" class="form-control">
                    <option value="">--Select--</option>
                    <option value="1">State</option>
                    <option value="2">City</option>
                  </select>
                </div>
					</div>


              </div>
              <!-- /.card-body -->
              <div class="card-footer">
                <button type="submit" name="generateQR" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div>
          <!-- /.card -->
        </div>
        <!--/.col (left) -->
        <!-- right column -->
        <div class="col-md-6">

        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </div><!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php include "include/footer.php"; ?>
<script>
  $(document).ready(function() {

	
	$('#erpZone').on('change', function() {
      var zone_id = $(this).val();

      if (zone_id) {
        $.ajax({
          type: 'POST',
          url: 'ajaxData.php',
          data: {
            'zone_id': zone_id
          },
          success: function(data) {
            $("#state").html(data);
          }
        });
      } else {
        $('#state').html('<option value="">Select zone first</option>');
      }
    });



    //State
    $('#state').on('change', function() {
      var state_id = $(this).val();

      if (state_id) {
        $.ajax({
          type: 'POST',
          url: 'ajaxData.php',
          data: {
            'state_id': state_id
          },
          success: function(data) {
            $("#city").html(data);
          }
        });
      } else {
        $('#city').html('<option value="">Select State first</option>');
      }
    });

	 

	 $('#erpBrand').on('change', function() {
      var brand_id = $(this).val();

      if (brand_id) {
        $.ajax({
          type: 'POST',
          url: 'ajaxData.php',
          data: {
            'brand_id': brand_id
          },
          success: function(data) {
            $("#product").html(data);
          }
        });
      } else {
        $('#product').html('<option value="">Select Brand first</option>');
      }
    });

	 $("input[name='buyer_type']:radio").change(function(){
        //alert($(this).val());
		  var buyer_type = $(this).val();
		  var erpBrand = $('#erpBrand').val();
		  var erpZone = $('#erpZone').val();
		  var erpState = $('#state').val();
		  var erpCity = $('#city').val();

		  //alert(erpBrand);alert(erpZone);alert(erpState);alert(erpCity);

		  if (buyer_type) {
        $.ajax({
          type: 'POST',
          url: 'ajaxData.php',
          data: {
            'buyer_type': buyer_type,'erpBrand':erpBrand,'erpZone':erpZone,'erpState':erpState,'erpCity':erpCity
          },
          success: function(data) {
				 //alert(data);
				 //console.log(data);
            $("#buyer_type").html(data);
          }
        });
      } else {
        $('#buyer_type').html('<option value="">Select buyer first</option>');
      }
    });



	 $("input[name='mode']:radio").change(function(){
        //alert($(this).val());
		  //$('#qrcode_form').trigger("reset");
		  var mode = $(this).val();

		  if (mode == 'online') {
			
			$('#online_mode').show();
			$('#offline_mode').hide();
			//$('#qrcode_form')[0].reset();
			//$('#qrcode_form').trigger("reset");
      } if (mode == 'offline') {
			
			$('#online_mode').hide();
			$('#offline_mode').show();
			$('#qrcode_form')[0].reset();
			//$('#qrcode_form').trigger("reset");
      }
    });



  });
</script>