<?php
	$conn = mysqli_connect("localhost","root","","blog_samples") or die(mysqli_error($conn));

?>

