<?php

$url = "https://www.googleapis.com/geolocation/v1/geolocate?key=AIzaSyCKujbP3gEUfWWA8Igiw7wGUE2KsuCfaVc";
$data = ['collection' => 'RapidAPI'];
$curl = curl_init($url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($curl, CURLOPT_HTTPHEADER, [
'X-RapidAPI-Host: kvstore.p.rapidapi.com',
'X-RapidAPI-Key: AIzaSyCKujbP3gEUfWWA8Igiw7wGUE2KsuCfaVc',
'Content-Type: application/json'
]);
$response = curl_exec($curl);
curl_close($curl);
$getLoc = json_decode($response, true);
echo $lat = $getLoc['location']['lat'];
echo '<br>';
echo $lng = $getLoc['location']['lng'];

?>